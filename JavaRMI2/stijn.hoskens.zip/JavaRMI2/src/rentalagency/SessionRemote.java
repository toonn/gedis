package rentalagency;

import java.rmi.Remote;

public interface SessionRemote extends Remote {
}
