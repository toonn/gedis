package ds.gae.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

import com.google.appengine.api.datastore.Key;

@NamedQueries({@NamedQuery(name = "getCarsByType", query = "SELECT c FROM Car c "
		+ "WHERE c.type = :type ")})
@Entity
public class Car {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Key key;

	private int id;

	@ManyToOne
	private CarType type;

	@OneToMany(cascade = { CascadeType.PERSIST, CascadeType.REMOVE })
	private Set<Reservation> reservations;

	/***************
	 * CONSTRUCTOR *
	 ***************/

	public Car(int uid, CarType type) {
		this.id = uid;
		this.type = type;
		type.addCar(this);
		this.reservations = new HashSet<Reservation>();
	}

	/******
	 * ID *
	 ******/

	public Key getKey() {
		return key;
	}

	public int getId() {
		return id;
	}

	/************
	 * CAR TYPE *
	 ************/

	public CarType getType() {
		return type;
	}

	/****************
	 * RESERVATIONS *
	 ****************/

	public Set<Reservation> getReservations() {
		return reservations;
	}

	public boolean isAvailable(Date start, Date end) {
		if (!start.before(end))
			throw new IllegalArgumentException("Illegal given period");

		for (Reservation reservation : reservations) {
			if (reservation.getEndDate().before(start)
					|| reservation.getStartDate().after(end))
				continue;
			return false;
		}
		return true;
	}

	public void addReservation(Reservation res) {
		reservations.add(res);
	}

	public void removeReservation(Reservation reservation) {
		// equals-method for Reservation is required!
		reservations.remove(reservation);
	}
}